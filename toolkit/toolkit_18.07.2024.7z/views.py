from django.http import HttpResponse, HttpResponseNotFound, Http404, HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.template.loader import render_to_string

from toolkit.models import TrafficLightObjects

menu = [{'title': 'О сайте', 'url_name': 'about'},
        {'title': 'Возможности', 'url_name': 'options'},
        {'title': 'Обратная связь', 'url_name': 'contact'},
        {'title': 'Вход', 'url_name': 'login'},
       ]

# data_db = [
#     {'id': 1, 'title': 'Управление по SNMP', 'is_published': True},
#     {'id': 2, 'title': 'Фильтр SNMP', 'is_published': True},
#     {'id': 3, 'title': 'Расчет цикла и сдвигов', 'is_published': True},
#     {'id': 4, 'title': 'Расчет конфликтов', 'is_published': True},
# ]


data_db = [
    {'id': 1, 'title': 'Управление по SNMP', 'url_name': 'manage_snmp'},
    {'id': 2, 'title': 'Фильтр SNMP', 'url_name': 'filter_snmp'},
    {'id': 3, 'title': 'Расчет цикла и сдвигов', 'url_name': 'calc_cyc'},
    {'id': 4, 'title': 'Расчет конфликтов', 'url_name': 'calc_conflicts'},
]

data_db2 = ['Управление по SNMP', 'Фильтр SNMP',
            'Расчет цикла и сдвигов', 'Расчет конфликтов'
]

# controller_types_db = [
#     {'id': 1, 'name': 'Swarco'},
#     {'id': 2, 'name': 'Peek'},
#     {'id': 3, 'name': 'Поток S'},
#     {'id': 4, 'name': 'Поток'}
# ]

controller_types_db = ['Swarco', 'Peek', 'Поток S', 'Поток']


def index(request):

    data = {'title': 'Главная страница',
            'menu': menu,
            'menu2': data_db2,
            'posts': data_db,
            'controllers': controller_types_db,
           }
    return render(request, 'toolkit/index.html', context=data)

def about(request):
    return render(request, 'toolkit/about.html', {'title': 'О сайте', 'menu': menu})

def manage_snmp(request):

    return render(request, 'toolkit/manage_snmp.html',)


def contact(request):
    return HttpResponse('Обратная связь')

def login(request):
    return HttpResponse('Авторизация')

def options(request):
    return HttpResponse('Возможности')

def show_tab(request, post_id):
    print('1')
    controller = get_object_or_404(TrafficLightObjects, pk=post_id)


    data = {
        'num_CO': controller.ip_adress,
        'menu': menu,
        'controller': controller,
        'cat_selected': 1,

    }

    return render(request, 'toolkit/about_controller.html', context=data)


    # return HttpResponse(f'Отображение вкладки с id = {post_id}')


def calc_cyc(request):
    print('calc_cyc')
    return HttpResponse(request, 'toolkit/calc_cyc.html')

def calc_conflicts(request):
    print('calc_conflicts')
    data = {'title': 'Расчёт конфликтов', 'menu': menu}
    return render(request, 'toolkit/calc_conflicts.html', context=data)



# def tabs(request, tabs_id):
#     return HttpResponse(f'<h1> Странца приложения tabs </h1><p>id: {tabs_id}</p>')
#
#
# def tabs_by_slug(request, tabs_slug):
#     print(request.GET)
#     return HttpResponse(f'<h1> Странца приложения tabs </h1><p>slug: {tabs_slug}</p>')
#
# def main_page(request):
#     return HttpResponse('Главная страница')
#
#
# def archive(request, year):
#     if year > 2024:
#         uri = reverse('tabs_slug', args=('test', ))
#         return HttpResponseRedirect('/')


def page_not_found(request, exception):
    return HttpResponseNotFound("<h1> Страница не найдена </h1>")